import { useState, useRef, useEffect } from "react";

const C = {
  card: "rgba(255,255,255,0.05)",
  border: "rgba(255,255,255,0.09)",
  blue: "#0055ff",
  green: "#00e87a",
  orange: "#ff9500",
  red: "#ff4444",
  white: "#ffffff",
  muted: "#7a9a88",
  purple: "#a855f7",
};
const G = "linear-gradient(160deg,#0a1a12,#0d1b2a)";

const PROPS = [
  { id: 1, landlord: "Mr. Chukwu Obi", phone: "+234 803 XXX XXXX", location: "Rukpwokwu, Port Harcourt", price: "₦450,000/yr", monthly: "₦37,500/mo", bedrooms: 2, image: "🏠", gps: { lat: 4.8156, lng: 7.0498 }, rating: 4.8, images: [{ e: "🛋️", l: "Living Room" }, { e: "🛏️", l: "Bedroom" }, { e: "🍳", l: "Kitchen" }, { e: "🚿", l: "Bathroom" }, { e: "🪴", l: "Balcony" }, { e: "🏘️", l: "Exterior" }], video: "2:15" },
  { id: 2, landlord: "Mrs. Adaeze Nwosu", phone: "+234 805 XXX XXXX", location: "Oyigbo, Rivers State", price: "₦380,000/yr", monthly: "₦31,667/mo", bedrooms: 3, image: "🏘️", gps: { lat: 4.8826, lng: 7.1321 }, rating: 4.5, images: [{ e: "🛋️", l: "Living Area" }, { e: "🛏️", l: "Bedroom 1" }, { e: "🚪", l: "Bedroom 2" }, { e: "🍳", l: "Kitchen" }, { e: "🚽", l: "Toilet" }, { e: "🌳", l: "Compound" }], video: "1:45" },
  { id: 3, landlord: "Chief Emeka Ike", phone: "+234 807 XXX XXXX", location: "Eleme, Port Harcourt", price: "₦550,000/yr", monthly: "₦45,833/mo", bedrooms: 4, image: "🏡", gps: { lat: 4.7833, lng: 7.1167 }, rating: 4.9, images: [{ e: "🏡", l: "Front View" }, { e: "🛋️", l: "Living Room" }, { e: "🛏️", l: "Master Suite" }, { e: "👨‍🍳", l: "Kitchen" }, { e: "🚗", l: "Parking" }, { e: "🌿", l: "Backyard" }], video: "3:20" },
];

const TENANTS = [
  { id: 1, name: "Chidi Okafor", age: 34, gender: "Male", family: 4, phone: "+234 803 456 7890", nok: "Amaka Okafor", nokPhone: "+234 805 123 4567", address: "15 Rukpwokwu St, PH", rent: "₦450,000", days: 13, online: true },
  { id: 2, name: "Ngozi Adeyemi", age: 29, gender: "Female", family: 2, phone: "+234 807 234 5678", nok: "Tunde Adeyemi", nokPhone: "+234 808 765 4321", address: "22 Oyigbo Rd, Rivers", rent: "₦380,000", days: 34, online: true },
  { id: 3, name: "Emeka Nwankwo", age: 42, gender: "Male", family: 5, phone: "+234 810 345 6789", nok: "Chioma Nwankwo", nokPhone: "+234 811 456 7890", address: "8 Eleme Close, PH", rent: "₦550,000", days: 52, online: false },
  { id: 4, name: "Fatima Ibrahim", age: 31, gender: "Female", family: 3, phone: "+234 813 678 9012", nok: "Musa Ibrahim", nokPhone: "+234 814 789 0123", address: "45 Rumuola Ave, PH", rent: "₦420,000", days: 67, online: false },
];

const LANGS = [
  { code: "english", flag: "🇬🇧", label: "English", greeting: "Hi! I'm Navi 👋 I'll guide you step by step. Where are you starting from?", ph: "Type your message...", instr: "clear simple Nigerian English. Be warm." },
  { code: "pidgin", flag: "🇳🇬", label: "Pidgin", greeting: "Navi here! 👋 Oga/Madam I go guide you reach the house. Where you dey start from?", ph: "Type wetin you wan say...", instr: "Nigerian Pidgin. Use Oga, abeg, sharp sharp." },
  { code: "yoruba", flag: "🟢", label: "Yoruba", greeting: "Ẹ káàbọ̀! 👋 Mo jẹ́ Navi. Níbo ni o wà báyìí?", ph: "Kọ ohun tí o fẹ́ sọ...", instr: "Yoruba language." },
  { code: "igbo", flag: "🔵", label: "Igbo", greeting: "Ndewo! 👋 Abụ m Navi. Ebe ị nọ ugbu a?", ph: "Dee ihe ị chọrọ ikwu...", instr: "Igbo language." },
  { code: "hausa", flag: "🟡", label: "Hausa", greeting: "Sannu! 👋 Ni ne Navi. Ina kuke yanzu?", ph: "Rubuta abin da kake so...", instr: "Hausa language." },
];

const CORENT_POSTS = [
  { id: 1, name: "Amara Okonkwo", age: 26, gender: "Female", flat: "2-Bedroom", amount: "380000", location: "Rukpwokwu, PH", share: "₦190,000 each", bio: "Clean and quiet. No parties. Work from home. Looking for 1 serious female co-renter.", verified: true, time: "2 hrs ago", contact: "+2348031112222", status: "searching" },
  { id: 2, name: "Tunde Afolabi", age: 30, gender: "Male", flat: "3-Bedroom", amount: "540000", location: "Eleme, Port Harcourt", share: "₦180,000 each", bio: "I have a good apartment lined up. Need 2 people to split 3 ways. Employed, responsible.", verified: true, time: "5 hrs ago", contact: "+2348073334444", status: "has_apartment" },
  { id: 3, name: "Fatima Bello", age: 24, gender: "Female", flat: "Self-Contain", amount: "200000", location: "Oyigbo, Rivers State", share: "₦100,000 each", bio: "NYSC corp member. Need one female co-renter. Quiet lifestyle, no visitors after 10pm.", verified: true, time: "1 day ago", contact: "+2348105556666", status: "searching" },
  { id: 4, name: "Emeka Obi", age: 35, gender: "Male", flat: "2-Bedroom", amount: "450000", location: "Rumuola, Port Harcourt", share: "₦225,000 each", bio: "Civil servant. Need 1 responsible male co-renter. I already have the apartment.", verified: true, time: "2 days ago", contact: "+2348137778888", status: "has_apartment" },
  { id: 5, name: "Grace Nwosu", age: 28, gender: "Female", flat: "3-Bedroom", amount: "600000", location: "Rukpwokwu, PH", share: "₦200,000 each", bio: "Looking for 2 co-renters. No apartment yet, let us find one together. Female preferred.", verified: true, time: "3 days ago", contact: "+2348169990000", status: "searching" },
  { id: 6, name: "Ibrahim Musa", age: 32, gender: "Male", flat: "2-Bedroom", amount: "420000", location: "Eleme, Port Harcourt", share: "₦210,000 each", bio: "Accountant. Looking for 1 co-renter. Already identified apartment, very decent area.", verified: true, time: "4 days ago", contact: "+2348192223333", status: "has_apartment" },
];

export default function App() {
  const [screen, setScreen] = useState("landing");
  const [role, setRole] = useState("");
  const [tab, setTab] = useState("browse");
  const [prop, setProp] = useState<any>(null);
  const [navi, setNavi] = useState<string | null>(null);

  const go = (r: string) => { setRole(r); setTab(r === "landlord" ? "dash" : "browse"); setProp(null); setScreen("main"); };
  if (screen === "landing") return <Landing onRole={go} />;

  return (
    <div style={{ background: G, minHeight: "100vh", color: C.white, maxWidth: 480, margin: "0 auto", display: "flex", flexDirection: "column", fontFamily: "system-ui,sans-serif" }}>
      <style>{`*{box-sizing:border-box;margin:0;padding:0}::-webkit-scrollbar{width:0}@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}@keyframes bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}`}</style>
      <TopBar role={role} onSwitch={(r) => { setRole(r); setTab(r === "landlord" ? "dash" : "browse"); setProp(null); }} onHome={() => setScreen("landing")} />
      {role === "tenant" && <TTabs tab={tab} onTab={(t) => { setTab(t); setProp(null); }} />}
      {role === "landlord" && <LTabs tab={tab} onTab={setTab} />}
      <div style={{ flex: 1, overflowY: "auto" }}>
        {role === "landlord" && tab === "dash" && <LDash />}
        {role === "landlord" && tab === "list" && <ListProp />}
        {role === "landlord" && tab === "earn" && <Earn />}
        {role === "tenant" && !prop && tab === "browse" && <Browse onSelect={setProp} />}
        {role === "tenant" && !prop && tab === "pay" && <Pay />}
        {role === "tenant" && !prop && tab === "chat" && <Chat />}
        {role === "tenant" && !prop && tab === "corent" && <CoRent />}
        {role === "tenant" && !prop && tab === "link" && <MyLink />}
        {role === "tenant" && !prop && tab === "profile" && <Profile />}
        {role === "tenant" && !prop && tab === "rent" && <Rent />}
        {role === "tenant" && !prop && tab === "loans" && <Loans />}
        {role === "tenant" && prop && !navi && <PropDetail prop={prop} onBack={() => setProp(null)} onNavi={setNavi} />}
      </div>
      {prop && navi === "voice" && <NaviVoice prop={prop} onClose={() => setNavi(null)} />}
      {prop && navi === "map" && <NaviMap prop={prop} onClose={() => setNavi(null)} />}
      {prop && navi === "bot" && <NaviBot prop={prop} onClose={() => setNavi(null)} />}
    </div>
  );
}

function Landing({ onRole }: { onRole: (r: string) => void }) {
  return (
    <div style={{ background: "linear-gradient(160deg,#071510,#091522)", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 28, fontFamily: "system-ui,sans-serif" }}>
      <style>{`*{box-sizing:border-box;margin:0;padding:0}`}</style>
      <div style={{ width: 90, height: 90, borderRadius: 24, background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 48, marginBottom: 24, boxShadow: "0 16px 48px rgba(0,232,122,0.3)" }}>🏠</div>
      <div style={{ fontWeight: 800, fontSize: 32, letterSpacing: -1.5, marginBottom: 6, textAlign: "center" }}>E-RentalHQ</div>
      <div style={{ color: C.green, fontSize: 14, fontWeight: 700, marginBottom: 10 }}>No Agents · No Lump Sum · No Stress</div>
      <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 13, textAlign: "center", lineHeight: 1.75, marginBottom: 40, maxWidth: 280 }}>Nigeria's monthly rent platform. We pay your landlord upfront. You repay us monthly.</div>
      <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 14 }}>
        <button onClick={() => onRole("tenant")} style={{ width: "100%", background: "linear-gradient(135deg,#00e87a,#00b85e)", border: "none", borderRadius: 16, padding: "20px", color: "#071510", fontWeight: 800, fontSize: 18, cursor: "pointer" }}>🏠  I'm a Tenant</button>
        <button onClick={() => onRole("landlord")} style={{ width: "100%", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "20px", color: C.white, fontWeight: 800, fontSize: 18, cursor: "pointer" }}>🏢  I'm a Landlord</button>
      </div>
      <div style={{ marginTop: 32, display: "flex", gap: 24, fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
        <span>✓ GPS Verified</span><span>✓ Zero Agents</span><span>✓ AI Voice Guide</span>
      </div>
    </div>
  );
}

function TopBar({ role, onSwitch, onHome }: any) {
  return (
    <div style={{ background: "linear-gradient(90deg,#071510,#091522)", padding: "12px 16px", borderBottom: "1px solid rgba(0,232,122,0.12)", flexShrink: 0 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div onClick={onHome} style={{ display: "flex", alignItems: "center", gap: 9, cursor: "pointer" }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>🏠</div>
          <div><div style={{ fontWeight: 800, fontSize: 16 }}>E-RentalHQ</div><div style={{ fontSize: 9, color: C.green, fontWeight: 600 }}>No Agents · Direct · Smart Pay</div></div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {["tenant", "landlord"].map(r => <button key={r} onClick={() => onSwitch(r)} style={{ background: role === r ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 8, padding: "5px 12px", color: role === r ? "#071510" : C.white, fontSize: 11, fontWeight: 700, cursor: "pointer" }}>{r === "tenant" ? "🏠 Tenant" : "🏢 Landlord"}</button>)}
        </div>
      </div>
    </div>
  );
}

function TTabs({ tab, onTab }: any) {
  const ts = [{ id: "browse", i: "🔍", l: "Browse" }, { id: "pay", i: "💳", l: "Pay" }, { id: "chat", i: "💬", l: "Chat" }, { id: "corent", i: "🤝", l: "Co-Rent" }, { id: "link", i: "🔗", l: "Link" }, { id: "profile", i: "👤", l: "Profile" }, { id: "rent", i: "🏦", l: "Rent" }, { id: "loans", i: "🎓", l: "Loans" }];
  return (
    <div style={{ background: "rgba(7,21,16,0.9)", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", overflowX: "auto", flexShrink: 0 }}>
      {ts.map(t => <button key={t.id} onClick={() => onTab(t.id)} style={{ minWidth: 54, padding: "10px 4px", background: "none", border: "none", borderBottom: "2px solid " + (tab === t.id ? C.green : "transparent"), color: tab === t.id ? C.green : C.muted, cursor: "pointer", fontSize: 9, fontWeight: 700, flexShrink: 0, textAlign: "center" as const }}>
        <div style={{ fontSize: 14 }}>{t.i}</div>{t.l}
      </button>)}
    </div>
  );
}

function LTabs({ tab, onTab }: any) {
  const ts = [{ id: "dash", i: "📊", l: "Dashboard" }, { id: "list", i: "📸", l: "List Property" }, { id: "earn", i: "💰", l: "Earnings" }];
  return (
    <div style={{ background: "rgba(7,21,16,0.9)", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", flexShrink: 0 }}>
      {ts.map(t => <button key={t.id} onClick={() => onTab(t.id)} style={{ flex: 1, padding: "10px 6px", background: "none", border: "none", borderBottom: "2px solid " + (tab === t.id ? C.green : "transparent"), color: tab === t.id ? C.green : C.muted, cursor: "pointer", fontSize: 9, fontWeight: 700, textAlign: "center" as const }}>
        <div style={{ fontSize: 14 }}>{t.i}</div>{t.l}
      </button>)}
    </div>
  );
}

function Browse({ onSelect }: any) {
  const [s, setS] = useState("");
  const [f, setF] = useState("All");
  const list = PROPS.filter(p => (f === "All" || p.bedrooms === parseInt(f)) && p.location.toLowerCase().includes(s.toLowerCase()));
  return (
    <div style={{ padding: 16 }}>
      <input value={s} onChange={e => setS(e.target.value)} placeholder="🔍 Search location..." style={{ width: "100%", background: "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 10, padding: "11px 14px", color: C.white, fontSize: 13, outline: "none", marginBottom: 10 }} />
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {["All", "2", "3", "4"].map(v => <button key={v} onClick={() => setF(v)} style={{ background: f === v ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 20, padding: "6px 14px", color: f === v ? "#071510" : C.white, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>{v === "All" ? "All" : v + " Bed"}</button>)}
      </div>
      {list.map(p => (
        <div key={p.id} onClick={() => onSelect(p)} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 16, padding: 16, cursor: "pointer", marginBottom: 12, animation: "fadeIn 0.3s ease" }}>
          <div style={{ display: "flex", gap: 14, marginBottom: 10 }}>
            <div style={{ width: 64, height: 64, borderRadius: 12, background: "linear-gradient(135deg,#071510,#091522)", border: "1px solid rgba(0,232,122,0.12)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, flexShrink: 0 }}>{p.image}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ fontWeight: 700, fontSize: 14 }}>{p.location}</span><span style={{ color: "#fbbf24", fontSize: 12 }}>⭐{p.rating}</span></div>
              <div style={{ color: C.green, fontWeight: 800, fontSize: 18, margin: "2px 0" }}>{p.price}</div>
              <div style={{ color: C.muted, fontSize: 12 }}>{p.monthly} · No agent fee</div>
              <div style={{ fontSize: 11, color: C.muted, marginTop: 3 }}>🛏 {p.bedrooms} bed · {p.landlord}</div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.2)" }}>📸 {p.images.length} photos · 🎥 {p.video}</span>
            <span style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", borderRadius: 8, padding: "5px 14px", fontSize: 12, fontWeight: 700, color: "#071510" }}>View →</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function PropDetail({ prop: p, onBack, onNavi }: any) {
  const [sel, setSel] = useState(0);
  const [vid, setVid] = useState(false);
  const [safety, setSafety] = useState(false);
  const navs = [
    { id: "voice", icon: "🎙️", title: "Navi AI Voice", sub: "Hands-free voice in 5 Nigerian languages", color: C.green },
    { id: "map", icon: "🗺️", title: "Turn-by-Turn Map", sub: "Step-by-step route with Nigerian landmarks", color: "#60aaff" },
    { id: "bot", icon: "🤖", title: "Location-Aware Chatbot", sub: "Reads your live GPS — exact directions", color: C.purple },
  ];
  return (
    <div style={{ animation: "fadeIn 0.3s ease" }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", gap: 10, alignItems: "center" }}>
        <button onClick={onBack} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.15)", borderRadius: 8, padding: "6px 12px", color: C.white, fontSize: 12, cursor: "pointer" }}>← Back</button>
        <span style={{ fontWeight: 700, fontSize: 13 }}>{p.location}</span>
      </div>
      <div style={{ background: "linear-gradient(160deg,#071510,#091522)", padding: "28px 20px", textAlign: "center", minHeight: 160, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        {vid ? <><div style={{ fontSize: 60 }}>🎥</div><div style={{ color: C.white, fontWeight: 600, marginTop: 6 }}>Video Tour · {p.video}</div><button onClick={() => setVid(false)} style={{ marginTop: 8, background: "rgba(255,255,255,0.08)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 7, padding: "6px 14px", color: C.white, fontSize: 11, cursor: "pointer" }}>← Photos</button></> : <><div style={{ fontSize: 72 }}>{p.images[sel].e}</div><div style={{ color: "#ccc", fontSize: 13, fontWeight: 600 }}>{p.images[sel].l}</div><div style={{ color: C.muted, fontSize: 11 }}>Photo {sel + 1}/{p.images.length}</div></>}
      </div>
      <div style={{ padding: "8px 16px", background: "rgba(7,21,16,0.8)", display: "flex", gap: 8, overflowX: "auto", borderBottom: "1px solid rgba(0,232,122,0.08)" }}>
        {p.images.map((img: any, i: number) => <button key={i} onClick={() => { setSel(i); setVid(false); }} style={{ width: 46, height: 46, borderRadius: 8, border: "2px solid " + (sel === i && !vid ? "rgba(0,232,122,0.6)" : "rgba(255,255,255,0.08)"), background: C.card, fontSize: 20, cursor: "pointer", flexShrink: 0 }}>{img.e}</button>)}
        <button onClick={() => setVid(true)} style={{ width: 46, height: 46, borderRadius: 8, border: "2px solid " + (vid ? C.red : "rgba(255,255,255,0.08)"), background: C.card, fontSize: 20, cursor: "pointer", flexShrink: 0 }}>🎥</button>
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontWeight: 800, fontSize: 19 }}>{p.location}</div>
          <div style={{ color: C.green, fontWeight: 800, fontSize: 22 }}>{p.price}</div>
          <div style={{ color: C.muted, fontSize: 12 }}>{p.monthly} · Zero agent fee · {p.bedrooms} bed · ⭐{p.rating}</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
          {[{ l: "Landlord", v: p.landlord }, { l: "Phone", v: p.phone }, { l: "Bedrooms", v: p.bedrooms + " Bed" }, { l: "GPS", v: p.gps.lat + ", " + p.gps.lng }].map(s => (
            <div key={s.l} style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.1)", borderRadius: 10, padding: "9px 11px" }}>
              <div style={{ color: C.muted, fontSize: 9, fontWeight: 700, textTransform: "uppercase", marginBottom: 2 }}>{s.l}</div>
              <div style={{ color: C.white, fontSize: 11, fontWeight: 600 }}>{s.v}</div>
            </div>
          ))}
        </div>
        <div style={{ background: "rgba(255,149,0,0.06)", border: "1px solid rgba(255,149,0,0.15)", borderRadius: 12, padding: "12px 14px", marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}><span>🛡</span><span style={{ color: C.orange, fontWeight: 700, fontSize: 13 }}>Safety First</span></div>
          {!safety ? <button onClick={() => setSafety(true)} style={{ background: C.orange, border: "none", borderRadius: 7, padding: "7px 14px", color: "#000", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>📍 Share My Location</button> : (
            <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
              {[{ i: "👥", l: "Share with E-RentalHQ Contacts" }, { i: "💬", l: "Share via WhatsApp" }].map(s => <button key={s.l} onClick={() => alert("Location shared!\n" + p.location + "\nGPS: " + p.gps.lat + ", " + p.gps.lng)} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 8, padding: "9px 12px", color: C.white, fontSize: 12, cursor: "pointer", textAlign: "left", display: "flex", gap: 10, alignItems: "center" }}><span style={{ fontSize: 18 }}>{s.i}</span>{s.l}</button>)}
            </div>
          )}
        </div>
        <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 12 }}>Navigate to this Property</div>
        {navs.map(n => (
          <button key={n.id} onClick={() => onNavi(n.id)} style={{ width: "100%", background: "rgba(0,0,0,0.25)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, padding: "14px 16px", cursor: "pointer", display: "flex", alignItems: "center", gap: 14, textAlign: "left", marginBottom: 10 }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: "rgba(0,0,0,0.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>{n.icon}</div>
            <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14, color: n.color, marginBottom: 3 }}>{n.title}</div><div style={{ color: C.muted, fontSize: 12 }}>{n.sub}</div></div>
            <span style={{ color: C.muted, fontSize: 20 }}>›</span>
          </button>
        ))}
        <button style={{ width: "100%", background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 12, padding: "13px", color: C.white, fontWeight: 700, fontSize: 14, cursor: "pointer", marginTop: 4 }}>📞 Call Landlord</button>
      </div>
    </div>
  );
}

function NaviVoice({ prop, onClose }: any) {
  const [msgs, setMsgs] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [lang, setLang] = useState("english");
  const [started, setStarted] = useState(false);
  const [step, setStep] = useState(0);
  const [speaking, setSpeaking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inRef = useRef<HTMLInputElement>(null);
  const cl = LANGS.find(l => l.code === lang) || LANGS[0];

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const speak = (text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel(); setSpeaking(true);
    const u = new SpeechSynthesisUtterance(text);
    const vs = window.speechSynthesis.getVoices();
    const v = vs.find(v => v.lang === "en-NG") || vs.find(v => v.lang.startsWith("en"));
    if (v) u.voice = v; u.rate = 0.9;
    u.onend = () => setSpeaking(false); u.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
  };

  const startNavi = () => {
    setStarted(true); const g = cl.greeting;
    setMsgs([{ r: "a", text: g, t: new Date() }]);
    setTimeout(() => { speak(g); inRef.current?.focus(); }, 300);
  };

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    window.speechSynthesis?.cancel(); setSpeaking(false);
    const next = [...msgs, { r: "u", text, t: new Date() }];
    setMsgs(next); setInput(""); setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 200, system: "You are Navi, E-RentalHQ navigation guide. Destination: " + prop.location + " GPS:" + prop.gps.lat + "," + prop.gps.lng + ". Give ONE step at a time using real Nigerian landmarks. Respond in " + cl.instr + " Max 2 sentences.", messages: next.map((m: any) => ({ role: m.r === "a" ? "assistant" : "user", content: m.text })) }) });
      const d = await res.json();
      const reply = d.content?.[0]?.text || "Abeg try again";
      setMsgs(p => [...p, { r: "a", text: reply, t: new Date() }]);
      setStep(s => s + 1); setTimeout(() => speak(reply), 300);
    } catch { setMsgs(p => [...p, { r: "a", text: "Network wahala! Try again", t: new Date() }]); }
    setLoading(false);
  };

  const mic = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { alert("Voice not supported"); return; }
    const r = new SR(); r.lang = "en-NG"; r.interimResults = false;
    r.onresult = (e: any) => send(e.results[0][0].transcript); r.start();
  };

  const fmt = (d: Date) => d?.toLocaleTimeString("en-NG", { hour: "2-digit", minute: "2-digit" });

  if (!started) return (
    <div style={{ position: "fixed", inset: 0, background: G, zIndex: 100, display: "flex", flexDirection: "column", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ background: "linear-gradient(90deg,#071510,#091522)", padding: "12px 16px", borderBottom: "1px solid rgba(0,232,122,0.12)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div><div style={{ fontWeight: 800, fontSize: 15 }}>🎙️ Voice Navigation</div><div style={{ color: C.green, fontSize: 10 }}>{prop.location}</div></div>
        <button onClick={onClose} style={{ background: C.card, border: "none", borderRadius: 7, padding: "6px 12px", color: C.muted, fontSize: 12, cursor: "pointer" }}>✕</button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 14, alignItems: "center", justifyContent: "center" }}>
        <div style={{ fontSize: 64, textAlign: "center" }}>🎙️</div>
        <div style={{ textAlign: "center" }}><div style={{ fontWeight: 800, fontSize: 20, marginBottom: 6 }}>Voice Navigation</div><div style={{ color: C.muted, fontSize: 13, lineHeight: 1.6 }}>Choose your language then tap Start.</div></div>
        <div style={{ width: "100%", background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 14, padding: 14 }}>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 10 }}>Language</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {LANGS.map(l => <button key={l.code} onClick={() => setLang(l.code)} style={{ background: lang === l.code ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 12, padding: "10px 12px", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, flex: 1, minWidth: 60 }}>
              <span style={{ fontSize: 18 }}>{l.flag}</span>
              <span style={{ color: lang === l.code ? "#071510" : C.muted, fontSize: 10, fontWeight: 700 }}>{l.label}</span>
            </button>)}
          </div>
        </div>
        <button onClick={startNavi} style={{ width: "100%", background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 14, padding: "18px", color: "#071510", fontWeight: 800, fontSize: 17, cursor: "pointer" }}>🎙️ Start Voice Navigation</button>
      </div>
    </div>
  );

  return (
    <div style={{ position: "fixed", inset: 0, background: G, zIndex: 100, display: "flex", flexDirection: "column", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ background: "linear-gradient(90deg,#071510,#091522)", padding: "12px 16px", borderBottom: "1px solid rgba(0,232,122,0.12)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>🎙️</div>
          <div><div style={{ fontWeight: 700, fontSize: 13 }}>Navi Voice</div><div style={{ color: speaking ? C.orange : C.green, fontSize: 10 }}>{speaking ? "Speaking..." : "Ready"}</div></div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}><span>{cl.flag}</span><button onClick={onClose} style={{ background: C.card, border: "none", borderRadius: 7, padding: "6px 10px", color: C.muted, fontSize: 11, cursor: "pointer" }}>✕</button></div>
      </div>
      <div style={{ padding: "6px 14px", background: "rgba(7,21,16,0.9)", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
        <div style={{ display: "flex", gap: 3 }}>{[1, 2, 3, 4, 5].map(i => <div key={i} style={{ width: i <= Math.min(step, 5) ? 18 : 6, height: 5, borderRadius: 3, background: i <= Math.min(step, 5) ? C.green : "rgba(255,255,255,0.08)", transition: "all 0.4s" }} />)}</div>
        <span style={{ color: C.muted, fontSize: 10 }}>Step {step}</span>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: "flex", flexDirection: m.r === "u" ? "row-reverse" : "row", gap: 8, alignItems: "flex-end" }}>
            {m.r === "a" && <div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, flexShrink: 0 }}>🎙️</div>}
            <div style={{ maxWidth: "76%" }}>
              <div style={{ background: m.r === "u" ? "linear-gradient(135deg,#0055ff,#003ecc)" : "rgba(0,232,122,0.07)", borderRadius: m.r === "u" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", padding: "10px 13px", color: C.white, fontSize: 13, lineHeight: 1.6, border: m.r === "a" ? "1px solid rgba(0,232,122,0.15)" : "none" }}>{m.text}</div>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 3, justifyContent: m.r === "u" ? "flex-end" : "flex-start" }}>
                <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 9 }}>{fmt(m.t)}</span>
                {m.r === "a" && <button onClick={() => speak(m.text)} style={{ background: "none", border: "none", color: C.muted, fontSize: 11, cursor: "pointer" }}>🔊</button>}
              </div>
            </div>
          </div>
        ))}
        {loading && <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}><div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>🎙️</div><div style={{ background: "rgba(0,232,122,0.07)", borderRadius: "18px 18px 18px 4px", padding: "12px 14px", border: "1px solid rgba(0,232,122,0.15)", display: "flex", gap: 5 }}>{[0, 1, 2].map(i => <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: C.green, animation: `bounce 1.2s ${i * 0.2}s infinite` }} />)}</div></div>}
        <div ref={endRef} />
      </div>
      <div style={{ padding: "9px 13px 16px", background: "rgba(7,21,16,0.95)", borderTop: "1px solid rgba(0,232,122,0.1)", display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", background: "rgba(0,232,122,0.04)", borderRadius: 24, padding: "9px 13px", border: "1px solid rgba(0,232,122,0.15)" }}>
          <input ref={inRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send(input)} placeholder={cl.ph} style={{ background: "none", border: "none", outline: "none", color: C.white, fontSize: 13, flex: 1 }} />
        </div>
        <button onClick={mic} style={{ width: 44, height: 44, borderRadius: "50%", background: "rgba(0,232,122,0.1)", border: "1px solid rgba(0,232,122,0.2)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 18 }}>🎤</button>
        <button onClick={() => send(input)} disabled={!input.trim() || loading} style={{ width: 44, height: 44, borderRadius: "50%", background: input.trim() && !loading ? "linear-gradient(135deg,#00e87a,#009e54)" : "rgba(255,255,255,0.06)", border: "none", cursor: input.trim() && !loading ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 16, color: input.trim() && !loading ? "#071510" : "rgba(255,255,255,0.2)" }}>➤</button>
      </div>
    </div>
  );
}

function NaviMap({ prop, onClose }: any) {
  const [started, setStarted] = useState(false);
  const [cs, setCs] = useState(0);
  const steps = [
    { icon: "📍", i: "Start from your current location", l: "Your position", d: "0m" },
    { icon: "➡️", i: "Head east on the main road", l: "Pass First Bank on left", d: "200m" },
    { icon: "⬆️", i: "Continue past the market junction", l: "Rumuola Market on right", d: "450m" },
    { icon: "↗️", i: "Bear right at the filling station", l: "Total Filling Station", d: "300m" },
    { icon: "➡️", i: "Turn right after the church", l: "RCCG Parish on left", d: "150m" },
    { icon: "🏠", i: "Destination is on the left", l: prop.location, d: "50m" },
  ];
  return (
    <div style={{ position: "fixed", inset: 0, background: G, zIndex: 100, display: "flex", flexDirection: "column", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ background: "linear-gradient(90deg,#071510,#091522)", padding: "12px 16px", borderBottom: "1px solid rgba(96,170,255,0.2)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div><div style={{ fontWeight: 800, fontSize: 15 }}>🗺️ Turn-by-Turn Map</div><div style={{ color: "#60aaff", fontSize: 10 }}>{prop.location}</div></div>
        <button onClick={onClose} style={{ background: C.card, border: "none", borderRadius: 7, padding: "6px 12px", color: C.muted, fontSize: 12, cursor: "pointer" }}>✕</button>
      </div>
      {!started ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, gap: 16 }}>
          <div style={{ fontSize: 72 }}>🗺️</div>
          <div style={{ textAlign: "center" }}><div style={{ fontWeight: 800, fontSize: 20, marginBottom: 6 }}>Turn-by-Turn Navigation</div><div style={{ color: C.muted, fontSize: 13, lineHeight: 1.6 }}>Step-by-step to {prop.location}</div></div>
          <div style={{ background: "rgba(96,170,255,0.08)", border: "1px solid rgba(96,170,255,0.2)", borderRadius: 12, padding: 14, width: "100%" }}>
            {[{ l: "Destination", v: prop.location }, { l: "GPS", v: prop.gps.lat + ", " + prop.gps.lng }, { l: "Distance", v: "~3.2 km" }, { l: "ETA", v: "~18 mins by keke" }].map(s => <div key={s.l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}><span style={{ color: C.muted, fontSize: 12 }}>{s.l}</span><span style={{ fontWeight: 600, fontSize: 12 }}>{s.v}</span></div>)}
          </div>
          <button onClick={() => setStarted(true)} style={{ width: "100%", background: "linear-gradient(135deg,#60aaff,#0055ff)", border: "none", borderRadius: 14, padding: "18px", color: C.white, fontWeight: 800, fontSize: 17, cursor: "pointer" }}>📍 Start Navigation</button>
        </div>
      ) : (
        <>
          <div style={{ background: "linear-gradient(135deg,#0a1f2e,#0d2a1a)", height: 200, flexShrink: 0, position: "relative", overflow: "hidden", borderBottom: "1px solid rgba(96,170,255,0.15)" }}>
            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.12 }}>
              {[0, 1, 2, 3, 4, 5, 6, 7].map(i => <line key={i} x1={i * 60} y1="0" x2={i * 60} y2="200" stroke="#60aaff" strokeWidth="1" />)}
              {[0, 1, 2, 3].map(i => <line key={i} x1="0" y1={i * 55} x2="480" y2={i * 55} stroke="#60aaff" strokeWidth="1" />)}
            </svg>
            <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}><polyline points="40,170 80,170 80,110 160,110 200,80 280,80 320,95" stroke="#00e87a" strokeWidth="3" fill="none" strokeDasharray="8,4" opacity="0.8" /></svg>
            <div style={{ position: "absolute", left: 28, bottom: 25, textAlign: "center" }}><div style={{ width: 26, height: 26, borderRadius: "50%", background: C.blue, border: "3px solid white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, margin: "0 auto" }}>📍</div><span style={{ color: C.white, fontSize: 8, fontWeight: 700, background: "rgba(0,0,0,0.6)", padding: "1px 4px", borderRadius: 3 }}>You</span></div>
            <div style={{ position: "absolute", right: 35, top: 18, textAlign: "center" }}><div style={{ width: 26, height: 26, borderRadius: "50%", background: C.green, border: "3px solid white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, margin: "0 auto" }}>🏠</div><span style={{ color: C.white, fontSize: 8, fontWeight: 700, background: "rgba(0,0,0,0.6)", padding: "1px 4px", borderRadius: 3 }}>Dest.</span></div>
            <div style={{ position: "absolute", top: 10, left: 10, background: "rgba(0,0,0,0.7)", borderRadius: 8, padding: "6px 10px", display: "flex", gap: 8 }}><span style={{ color: C.green, fontSize: 12, fontWeight: 800 }}>3.2 km</span><span style={{ color: C.muted, fontSize: 10 }}>~18 min</span></div>
          </div>
          <div style={{ background: "rgba(96,170,255,0.1)", border: "1px solid rgba(96,170,255,0.25)", margin: "12px 16px 0", borderRadius: 14, padding: "14px 16px", flexShrink: 0 }}>
            <div style={{ color: "#60aaff", fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>Next Direction</div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}><span style={{ fontSize: 32 }}>{steps[cs].icon}</span><div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{steps[cs].i}</div><div style={{ color: C.muted, fontSize: 12 }}>📌 {steps[cs].l} · {steps[cs].d}</div></div></div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px", display: "flex", flexDirection: "column", gap: 8 }}>
            {steps.map((s, i) => <div key={i} onClick={() => setCs(i)} style={{ background: cs === i ? "rgba(96,170,255,0.12)" : C.card, border: "1px solid " + (cs === i ? "rgba(96,170,255,0.3)" : "rgba(255,255,255,0.06)"), borderRadius: 12, padding: "12px 14px", cursor: "pointer", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: cs === i ? "rgba(96,170,255,0.2)" : i < cs ? "rgba(0,232,122,0.2)" : "rgba(255,255,255,0.05)", border: "2px solid " + (cs === i ? "#60aaff" : i < cs ? C.green : "rgba(255,255,255,0.1)"), display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{i < cs ? "✓" : s.icon}</div>
              <div style={{ flex: 1 }}><div style={{ fontWeight: 600, fontSize: 13, color: cs === i ? C.white : i < cs ? C.muted : "#aaa" }}>{s.i}</div><div style={{ color: C.muted, fontSize: 11, marginTop: 1 }}>{s.l} · {s.d}</div></div>
            </div>)}
          </div>
          <div style={{ padding: "10px 16px 20px", background: "rgba(7,21,16,0.95)", borderTop: "1px solid rgba(96,170,255,0.1)", display: "flex", gap: 10, flexShrink: 0 }}>
            <button onClick={() => setCs(s => Math.max(0, s - 1))} disabled={cs === 0} style={{ flex: 1, background: cs > 0 ? "rgba(96,170,255,0.1)" : C.card, border: "1px solid " + (cs > 0 ? "rgba(96,170,255,0.25)" : C.border), borderRadius: 12, padding: "12px", color: cs > 0 ? "#60aaff" : C.muted, fontWeight: 700, fontSize: 13, cursor: cs > 0 ? "pointer" : "not-allowed" }}>← Prev</button>
            {cs < steps.length - 1 ? <button onClick={() => setCs(s => s + 1)} style={{ flex: 2, background: "linear-gradient(135deg,#60aaff,#0055ff)", border: "none", borderRadius: 12, padding: "12px", color: C.white, fontWeight: 800, fontSize: 13, cursor: "pointer" }}>Next →</button> : <button onClick={() => alert("Arrived at " + prop.location + "! 🎉")} style={{ flex: 2, background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "12px", color: "#071510", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>Arrived! 🎉</button>}
          </div>
        </>
      )}
    </div>
  );
}

function NaviBot({ prop, onClose }: any) {
  const [msgs, setMsgs] = useState<any[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [loc, setLoc] = useState<any>(null);
  const [locating, setLocating] = useState(false);
  const [started, setStarted] = useState(false);
  const [lang, setLang] = useState("english");
  const endRef = useRef<HTMLDivElement>(null);
  const inRef = useRef<HTMLInputElement>(null);
  const cl = LANGS.find(l => l.code === lang) || LANGS[0];

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const start = () => {
    setLocating(true);
    const go = (lat: number, lng: number) => {
      setLoc({ lat, lng }); setLocating(false); setStarted(true);
      const dist = ((Math.abs(lat - prop.gps.lat) + Math.abs(lng - prop.gps.lng)) * 111).toFixed(1);
      const g = lang === "pidgin" ? `Navi here! I get your GPS — you dey ${lat.toFixed(4)}N, about ${dist}km from the house. Which transport — keke, bus, or walking?` : `Hi! Got your GPS — you're at ${lat.toFixed(4)}N, about ${dist}km from ${prop.location}. How do you want to travel?`;
      setMsgs([{ r: "a", text: g, t: new Date() }]);
      setTimeout(() => inRef.current?.focus(), 300);
    };
    navigator.geolocation ? navigator.geolocation.getCurrentPosition(p => go(p.coords.latitude, p.coords.longitude), () => go(4.81, 7.02)) : go(4.81, 7.02);
  };

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const next = [...msgs, { r: "u", text, t: new Date() }];
    setMsgs(next); setInput(""); setLoading(true);
    try {
      const lc = loc ? `User GPS:${loc.lat.toFixed(6)},${loc.lng.toFixed(6)}. Dest:${prop.gps.lat},${prop.gps.lng}. Dist:${((Math.abs(loc.lat - prop.gps.lat) + Math.abs(loc.lng - prop.gps.lng)) * 111).toFixed(1)}km.` : "No GPS.";
      const res = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 250, system: `You are Navi location-aware chatbot. ${lc} Destination: ${prop.location}. You know exact GPS. Give hyper-accurate directions. Mention distance. Respond in ${cl.instr} Max 3 sentences.`, messages: next.map((m: any) => ({ role: m.r === "a" ? "assistant" : "user", content: m.text })) }) });
      const d = await res.json();
      setMsgs(p => [...p, { r: "a", text: d.content?.[0]?.text || "Abeg try again", t: new Date() }]);
    } catch { setMsgs(p => [...p, { r: "a", text: "Network wahala! Try again", t: new Date() }]); }
    setLoading(false);
  };

  const fmt = (d: Date) => d?.toLocaleTimeString("en-NG", { hour: "2-digit", minute: "2-digit" });

  return (
    <div style={{ position: "fixed", inset: 0, background: G, zIndex: 100, display: "flex", flexDirection: "column", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ background: "linear-gradient(90deg,#071510,#091522)", padding: "12px 16px", borderBottom: "1px solid rgba(168,85,247,0.2)", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <div><div style={{ fontWeight: 800, fontSize: 15 }}>🤖 Location-Aware Chatbot</div><div style={{ color: loc ? C.green : C.muted, fontSize: 10 }}>{loc ? `📍 GPS: ${loc.lat.toFixed(4)}, ${loc.lng.toFixed(4)}` : "Waiting for GPS..."}</div></div>
          <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
            {LANGS.map(l => <button key={l.code} onClick={() => setLang(l.code)} style={{ background: lang === l.code ? "rgba(168,85,247,0.3)" : C.card, border: "1px solid " + (lang === l.code ? "rgba(168,85,247,0.5)" : C.border), borderRadius: 6, padding: "3px 6px", color: lang === l.code ? C.purple : C.muted, fontSize: 10, fontWeight: 700, cursor: "pointer" }}>{l.flag}</button>)}
            <button onClick={onClose} style={{ background: C.card, border: "none", borderRadius: 7, padding: "5px 9px", color: C.muted, fontSize: 11, cursor: "pointer", marginLeft: 4 }}>✕</button>
          </div>
        </div>
        <div style={{ background: "rgba(168,85,247,0.08)", borderRadius: 9, padding: "7px 12px", border: "1px solid rgba(168,85,247,0.2)", display: "flex", alignItems: "center", gap: 8 }}>
          <span>🏠</span>
          <div style={{ flex: 1 }}><div style={{ fontSize: 11, fontWeight: 700 }}>{prop.location}</div><div style={{ color: C.muted, fontSize: 9 }}>GPS: {prop.gps.lat}, {prop.gps.lng}</div></div>
          {loc && <div style={{ textAlign: "right" }}><div style={{ color: C.green, fontSize: 9, fontWeight: 700 }}>GPS Active</div><div style={{ color: C.muted, fontSize: 8 }}>{((Math.abs(loc.lat - prop.gps.lat) + Math.abs(loc.lng - prop.gps.lng)) * 111).toFixed(1)} km away</div></div>}
        </div>
      </div>
      {!started ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, gap: 16 }}>
          <div style={{ fontSize: 72 }}>🤖</div>
          <div style={{ textAlign: "center" }}><div style={{ fontWeight: 800, fontSize: 20, marginBottom: 6 }}>Location-Aware Chatbot</div><div style={{ color: C.muted, fontSize: 13, lineHeight: 1.6 }}>Reads your live GPS. Gives directions from exactly where you are.</div></div>
          <div style={{ background: "rgba(168,85,247,0.08)", border: "1px solid rgba(168,85,247,0.2)", borderRadius: 12, padding: 14, width: "100%" }}>
            {["Reads your live GPS in real time", "Calculates exact distance to property", "Directions based on your actual position", "Works in 5 Nigerian languages"].map(f => <div key={f} style={{ display: "flex", gap: 8, marginBottom: 6, fontSize: 12, color: "rgba(255,255,255,0.7)" }}><span style={{ color: C.purple }}>✓</span>{f}</div>)}
          </div>
          <button onClick={start} disabled={locating} style={{ width: "100%", background: "linear-gradient(135deg,#a855f7,#0055ff)", border: "none", borderRadius: 14, padding: "18px", color: C.white, fontWeight: 800, fontSize: 17, cursor: locating ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 12 }}>
            {locating ? <><div style={{ width: 20, height: 20, borderRadius: "50%", border: "2px solid rgba(255,255,255,0.3)", borderTop: "2px solid white", animation: "spin 1s linear infinite" }} /> Getting GPS...</> : <><span style={{ fontSize: 22 }}>📍</span> Share Location & Start</>}
          </button>
        </div>
      ) : (
        <>
          <div style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
            {msgs.map((m, i) => (
              <div key={i} style={{ display: "flex", flexDirection: m.r === "u" ? "row-reverse" : "row", gap: 8, alignItems: "flex-end" }}>
                {m.r === "a" && <div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg,#a855f7,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, flexShrink: 0 }}>🤖</div>}
                <div style={{ maxWidth: "76%" }}>
                  <div style={{ background: m.r === "u" ? "linear-gradient(135deg,#0055ff,#003ecc)" : "rgba(168,85,247,0.1)", borderRadius: m.r === "u" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", padding: "10px 13px", color: C.white, fontSize: 13, lineHeight: 1.6, border: m.r === "a" ? "1px solid rgba(168,85,247,0.2)" : "none" }}>{m.text}</div>
                  <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, marginTop: 3, textAlign: m.r === "u" ? "right" : "left" }}>{fmt(m.t)}</div>
                </div>
              </div>
            ))}
            {loading && <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}><div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg,#a855f7,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>🤖</div><div style={{ background: "rgba(168,85,247,0.1)", borderRadius: "18px 18px 18px 4px", padding: "12px 14px", border: "1px solid rgba(168,85,247,0.2)", display: "flex", gap: 5 }}>{[0, 1, 2].map(i => <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: C.purple, animation: `bounce 1.2s ${i * 0.2}s infinite` }} />)}</div></div>}
            <div ref={endRef} />
          </div>
          <div style={{ padding: "9px 13px 16px", background: "rgba(7,21,16,0.95)", borderTop: "1px solid rgba(168,85,247,0.1)", display: "flex", gap: 8, alignItems: "center", flexShrink: 0 }}>
            {loc && <div style={{ background: "rgba(0,232,122,0.1)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 8, padding: "6px 8px", flexShrink: 0, display: "flex", gap: 4, alignItems: "center" }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: C.green, display: "inline-block", animation: "pulse 2s infinite" }} /><span style={{ color: C.green, fontSize: 9, fontWeight: 700 }}>LIVE</span></div>}
            <div style={{ flex: 1, display: "flex", alignItems: "center", background: "rgba(168,85,247,0.05)", borderRadius: 24, padding: "9px 13px", border: "1px solid rgba(168,85,247,0.15)" }}>
              <input ref={inRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send(input)} placeholder={cl.ph} style={{ background: "none", border: "none", outline: "none", color: C.white, fontSize: 13, flex: 1 }} />
            </div>
            <button onClick={() => send(input)} disabled={!input.trim() || loading} style={{ width: 44, height: 44, borderRadius: "50%", background: input.trim() && !loading ? "linear-gradient(135deg,#a855f7,#0055ff)" : "rgba(255,255,255,0.06)", border: "none", cursor: input.trim() && !loading ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 16, color: input.trim() && !loading ? C.white : "rgba(255,255,255,0.2)" }}>➤</button>
          </div>
        </>
      )}
    </div>
  );
}

function CoRent() {
  const [view, setView] = useState("feed");
  const [showPost, setShowPost] = useState(false);
  const [posts, setPosts] = useState<any[]>(CORENT_POSTS);
  const [form, setForm] = useState({ flat: "", amount: "", location: "", bio: "", status: "searching" });
  const [filter, setFilter] = useState("all");
  const [contactId, setContactId] = useState<number | null>(null);
  const [notif, setNotif] = useState(true);

  const filtered = posts.filter(p => filter === "all" ? true : filter === "searching" ? p.status === "searching" : p.status === "has_apartment");

  const submitPost = () => {
    if (!form.flat || !form.amount || !form.location || !form.bio) return;
    const np = { id: posts.length + 1, name: "Chidi Okafor", age: 34, gender: "Male", flat: form.flat, amount: form.amount, location: form.location, share: "", bio: form.bio, verified: true, time: "Just now", contact: "+2348034567890", status: form.status };
    setPosts(p => [np, ...p]);
    setForm({ flat: "", amount: "", location: "", bio: "", status: "searching" });
    setShowPost(false);
  };

  if (showPost) return (
    <div style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <button onClick={() => setShowPost(false)} style={{ background: "rgba(0,232,122,0.08)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 8, padding: "6px 12px", color: C.green, fontSize: 12, cursor: "pointer", fontWeight: 700 }}>← Back</button>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Post Co-Rent Request</div><div style={{ color: C.muted, fontSize: 12 }}>Find your rent partner</div></div>
      </div>
      <div style={{ background: "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 14, padding: 14, marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#071510" }}>✓</div>
        <div><div style={{ fontWeight: 700, fontSize: 13, color: C.green }}>Verified Member — Chidi Okafor</div><div style={{ color: C.muted, fontSize: 11 }}>Your post will be visible to all verified users.</div></div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 8 }}>My Situation</div>
          <div style={{ display: "flex", gap: 8 }}>
            {[{ id: "searching", label: "No apartment yet", sub: "Looking for co-renter + apartment" }, { id: "has_apartment", label: "I have an apartment", sub: "Need co-renter to share cost" }].map(s => (
              <div key={s.id} onClick={() => setForm(f => ({ ...f, status: s.id }))} style={{ flex: 1, background: form.status === s.id ? "rgba(0,232,122,0.12)" : C.card, border: "2px solid " + (form.status === s.id ? "rgba(0,232,122,0.4)" : C.border), borderRadius: 12, padding: "10px 12px", cursor: "pointer" }}>
                <div style={{ fontWeight: 700, fontSize: 12, color: form.status === s.id ? C.green : C.white, marginBottom: 2 }}>{s.label}</div>
                <div style={{ color: C.muted, fontSize: 10 }}>{s.sub}</div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>Flat Type</div>
          <select value={form.flat} onChange={e => setForm(f => ({ ...f, flat: e.target.value }))} style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: form.flat ? C.white : C.muted, fontSize: 13, outline: "none" }}>
            <option value="">Select flat type *</option>
            {["Self-Contain", "1-Bedroom", "2-Bedroom", "3-Bedroom", "4-Bedroom", "Mini Flat", "Room & Parlour"].map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
        <div>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>Annual Rent Budget (₦)</div>
          <input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} placeholder="e.g. 400000" style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 14, outline: "none" }} />
        </div>
        <div>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>Preferred Location</div>
          <input type="text" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="e.g. Rukpwokwu, Port Harcourt" style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 13, outline: "none" }} />
        </div>
        <div>
          <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>About You & Preferences</div>
          <textarea value={form.bio} onChange={e => setForm(f => ({ ...f, bio: e.target.value }))} placeholder="Tell potential co-renters about yourself. Your lifestyle, preferences, work schedule, rules..." rows={4} style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 13, outline: "none", resize: "none" }} />
        </div>
        <button onClick={submitPost} style={{ width: "100%", background: form.flat && form.amount && form.location && form.bio ? "linear-gradient(135deg,#00e87a,#009e54)" : "rgba(255,255,255,0.06)", border: "none", borderRadius: 12, padding: "15px", color: form.flat && form.amount && form.location && form.bio ? "#071510" : C.muted, fontWeight: 800, fontSize: 16, cursor: form.flat && form.amount && form.location && form.bio ? "pointer" : "not-allowed" }}>
          Post Co-Rent Request
        </button>
      </div>
    </div>
  );

  if (contactId !== null) {
    const person = posts.find(p => p.id === contactId)!;
    return (
      <div style={{ padding: 16 }}>
        <button onClick={() => setContactId(null)} style={{ background: "rgba(0,232,122,0.08)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 8, padding: "6px 12px", color: C.green, fontSize: 12, cursor: "pointer", fontWeight: 700, marginBottom: 16 }}>← Back</button>
        <div style={{ background: "linear-gradient(135deg,rgba(0,232,122,0.1),rgba(0,85,255,0.07))", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 16, padding: 18, marginBottom: 16 }}>
          <div style={{ display: "flex", gap: 14, alignItems: "flex-start", marginBottom: 12 }}>
            <div style={{ position: "relative", flexShrink: 0 }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: "linear-gradient(135deg,#00e87a,#0055ff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: "#071510" }}>{person.name.split(" ").map((n: string) => n[0]).join("")}</div>
              <div style={{ position: "absolute", bottom: 0, right: 0, background: C.green, borderRadius: "50%", width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, color: "#071510", border: "2px solid #0a1a12" }}>✓</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 2 }}>{person.name}</div>
              <div style={{ color: C.muted, fontSize: 12 }}>{person.age} yrs · {person.gender}</div>
              <div style={{ display: "inline-block", background: person.status === "has_apartment" ? "rgba(0,232,122,0.15)" : "rgba(0,85,255,0.15)", color: person.status === "has_apartment" ? C.green : "#60aaff", borderRadius: 20, padding: "3px 10px", fontSize: 10, fontWeight: 700, marginTop: 4 }}>{person.status === "has_apartment" ? "✓ Has Apartment" : "🔍 Searching"}</div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
            {[{ l: "Flat Type", v: person.flat }, { l: "Annual Rent", v: "₦" + parseInt(person.amount).toLocaleString() }, { l: "Location", v: person.location }, { l: "Your Share", v: person.share || "Negotiable" }].map(s => (
              <div key={s.l} style={{ background: "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 10, padding: "9px 11px" }}>
                <div style={{ color: C.muted, fontSize: 9, fontWeight: 700, textTransform: "uppercase", marginBottom: 2 }}>{s.l}</div>
                <div style={{ color: C.white, fontSize: 11, fontWeight: 700 }}>{s.v}</div>
              </div>
            ))}
          </div>
          <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "11px 13px", borderLeft: "3px solid rgba(0,232,122,0.4)" }}>
            <div style={{ color: C.green, fontSize: 10, fontWeight: 700, marginBottom: 5 }}>ABOUT</div>
            <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 13, lineHeight: 1.6 }}>{person.bio}</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ background: "rgba(37,211,102,0.08)", border: "1px solid rgba(37,211,102,0.2)", borderRadius: 12, padding: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div><div style={{ fontWeight: 700, fontSize: 13, color: "#25d366" }}>💬 Chat on WhatsApp</div><div style={{ color: C.muted, fontSize: 11 }}>Send a direct message now</div></div>
            <button onClick={() => window.open(`https://wa.me/${person.contact.replace(/[^0-9]/g, "")}?text=Hi ${person.name}! I saw your co-rent post on E-RentalHQ. I am interested in the ${person.flat} in ${person.location}. Can we talk?`)} style={{ background: "#25d366", border: "none", borderRadius: 9, padding: "9px 16px", color: "#000", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>Chat Now</button>
          </div>
          <div style={{ background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div><div style={{ fontWeight: 700, fontSize: 13 }}>📞 Call Directly</div><div style={{ color: C.muted, fontSize: 11 }}>{person.contact}</div></div>
            <button onClick={() => window.open("tel:" + person.contact)} style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 9, padding: "9px 16px", color: "#071510", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>Call</button>
          </div>
          <div style={{ background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div><div style={{ fontWeight: 700, fontSize: 13 }}>💌 Message in App</div><div style={{ color: C.muted, fontSize: 11 }}>Use E-RentalHQ chat</div></div>
            <button style={{ background: "rgba(0,85,255,0.15)", border: "1px solid rgba(0,85,255,0.25)", borderRadius: 9, padding: "9px 16px", color: "#60aaff", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>Message</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {notif && (
        <div style={{ background: "linear-gradient(135deg,rgba(0,232,122,0.15),rgba(0,85,255,0.1))", borderBottom: "1px solid rgba(0,232,122,0.2)", padding: "10px 16px", display: "flex", gap: 10, alignItems: "center" }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: C.green, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "#071510", flexShrink: 0 }}>NEW</div>
          <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 13, color: C.green }}>3 new co-rent requests near you</div><div style={{ color: C.muted, fontSize: 11 }}>In Rukpwokwu, Eleme and Oyigbo</div></div>
          <button onClick={() => setNotif(false)} style={{ background: "none", border: "none", color: C.muted, fontSize: 14, cursor: "pointer" }}>✕</button>
        </div>
      )}
      <div style={{ padding: "14px 16px 0" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
          <div><div style={{ fontWeight: 800, fontSize: 20 }}>Co-Rent Connect</div><div style={{ color: C.muted, fontSize: 12 }}>Find verified rent partners near you</div></div>
          <button onClick={() => setShowPost(true)} style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 10, padding: "9px 14px", color: "#071510", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>+ Post</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, margin: "14px 0" }}>
          {[{ l: "Active Posts", v: posts.length, c: C.green }, { l: "Near You", v: "4", c: "#60aaff" }, { l: "Verified Only", v: "100%", c: C.purple }].map(s => (
            <div key={s.l} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 10, padding: "10px 8px", textAlign: "center" }}>
              <div style={{ fontWeight: 800, fontSize: 18, color: s.c }}>{s.v}</div>
              <div style={{ color: C.muted, fontSize: 9, fontWeight: 700 }}>{s.l}</div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 14, overflowX: "auto" }}>
          {[{ id: "all", label: "All Posts" }, { id: "searching", label: "No Apartment Yet" }, { id: "has_apartment", label: "Has Apartment" }].map(f => (
            <button key={f.id} onClick={() => setFilter(f.id)} style={{ background: filter === f.id ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "1px solid " + (filter === f.id ? "transparent" : C.border), borderRadius: 20, padding: "6px 12px", color: filter === f.id ? "#071510" : C.muted, fontSize: 10, fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0 }}>{f.label}</button>
          ))}
        </div>
      </div>
      <div style={{ padding: "0 16px 80px" }}>
        {filtered.map(p => (
          <div key={p.id} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 16, padding: 16, marginBottom: 12, animation: "fadeIn 0.3s ease" }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ position: "relative", flexShrink: 0 }}>
                <div style={{ width: 48, height: 48, borderRadius: "50%", background: "linear-gradient(135deg,rgba(0,232,122,0.3),rgba(0,85,255,0.3))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: C.white }}>{p.name.split(" ").map((n: string) => n[0]).join("")}</div>
                <div style={{ position: "absolute", bottom: 0, right: 0, background: C.green, borderRadius: "50%", width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 8, fontWeight: 800, color: "#071510", border: "2px solid #0a1a12" }}>✓</div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 2 }}>
                  <span style={{ fontWeight: 800, fontSize: 15 }}>{p.name}</span>
                  <span style={{ background: "rgba(0,232,122,0.12)", color: C.green, borderRadius: 20, padding: "1px 7px", fontSize: 9, fontWeight: 700 }}>VERIFIED</span>
                </div>
                <div style={{ color: C.muted, fontSize: 11 }}>{p.age} yrs · {p.gender} · {p.time}</div>
              </div>
              <div style={{ background: p.status === "has_apartment" ? "rgba(0,232,122,0.12)" : "rgba(0,85,255,0.12)", border: "1px solid " + (p.status === "has_apartment" ? "rgba(0,232,122,0.3)" : "rgba(0,85,255,0.3)"), borderRadius: 8, padding: "4px 8px", textAlign: "center", flexShrink: 0 }}>
                <div style={{ fontSize: 8, fontWeight: 800, color: p.status === "has_apartment" ? C.green : "#60aaff" }}>{p.status === "has_apartment" ? "HAS APT" : "SEARCHING"}</div>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 10 }}>
              {[{ l: "Flat Type", v: p.flat, c: "#60aaff" }, { l: "Annual Rent", v: "₦" + parseInt(p.amount).toLocaleString(), c: C.green }, { l: "Location", v: p.location, c: C.white }, { l: "Your Share", v: p.share || "Negotiable", c: C.orange }].map(s => (
                <div key={s.l} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 8, padding: "8px 10px" }}>
                  <div style={{ color: C.muted, fontSize: 8, fontWeight: 700, textTransform: "uppercase", marginBottom: 2 }}>{s.l}</div>
                  <div style={{ color: s.c, fontSize: 12, fontWeight: 700 }}>{s.v}</div>
                </div>
              ))}
            </div>
            <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 8, padding: "9px 11px", marginBottom: 12, borderLeft: "3px solid rgba(0,232,122,0.4)" }}>
              <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 12, lineHeight: 1.6 }}>{p.bio}</div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setContactId(p.id)} style={{ flex: 2, background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 10, padding: "11px", color: "#071510", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>🤝 I'm Interested</button>
              <button onClick={() => window.open(`https://wa.me/${p.contact.replace(/[^0-9]/g, "")}?text=Hi ${p.name}! I saw your co-rent post on E-RentalHQ.`)} style={{ flex: 1, background: "rgba(37,211,102,0.1)", border: "1px solid rgba(37,211,102,0.25)", borderRadius: 10, padding: "11px", color: "#25d366", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>WhatsApp</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Profile() {
  const pays = [{ m: "Jan 2026", s: "DUE", a: "₦37,500", c: C.orange }, { m: "Dec 2025", s: "PAID", a: "₦37,500", c: C.green }, { m: "Nov 2025", s: "DEFAULTED", a: "₦40,000", c: C.red }, { m: "Oct 2025", s: "PAID", a: "₦37,500", c: C.green }];
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 14 }}>My Profile</div>
      <div style={{ background: "linear-gradient(135deg,rgba(0,232,122,0.08),rgba(0,85,255,0.06))", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 16, padding: 16, marginBottom: 14, display: "flex", gap: 14, alignItems: "center" }}>
        <div style={{ fontSize: 56 }}>👨</div>
        <div style={{ flex: 1 }}><div style={{ fontWeight: 800, fontSize: 17 }}>Chidi Okafor</div><div style={{ color: C.muted, fontSize: 12, marginBottom: 4 }}>34y · Male · Family of 4</div><div style={{ fontSize: 12, color: C.muted }}>+234 803 456 7890</div></div>
        <div style={{ background: "rgba(255,68,68,0.1)", border: "2px solid " + C.red, borderRadius: 10, padding: "8px 12px", textAlign: "center" }}><div style={{ fontWeight: 800, fontSize: 24, color: C.red }}>13</div><div style={{ fontSize: 9, color: C.muted }}>days left</div></div>
      </div>
      <div style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 14, padding: 14 }}>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10 }}>Payment History</div>
        {pays.map((p, i) => (
          <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: i < pays.length - 1 ? "1px solid rgba(0,232,122,0.06)" : "none" }}>
            <div><div style={{ fontWeight: 600, fontSize: 13 }}>{p.m}</div><span style={{ background: p.c + "22", color: p.c, border: "1px solid " + p.c + "44", borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700 }}>{p.s}</span></div>
            <div style={{ fontWeight: 800, fontSize: 14, color: p.c }}>{p.a}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Rent() {
  const [rent, setRent] = useState("450000");
  const [months, setMonths] = useState("12");
  const monthly = () => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", minimumFractionDigits: 0 }).format((parseFloat(rent) || 0) / (parseFloat(months) || 1));
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 4 }}>Rent Payment</div>
      <div style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 14, padding: 16, marginBottom: 14 }}>
        <div style={{ marginBottom: 10 }}><div style={{ color: C.green, fontSize: 10, fontWeight: 700, marginBottom: 5, textTransform: "uppercase" }}>Annual Rent (₦)</div><input type="number" value={rent} onChange={e => setRent(e.target.value)} style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 16, outline: "none" }} /></div>
        <div style={{ marginBottom: 14 }}><div style={{ color: C.green, fontSize: 10, fontWeight: 700, marginBottom: 5, textTransform: "uppercase" }}>Repayment Period</div><select value={months} onChange={e => setMonths(e.target.value)} style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 14, outline: "none" }}>{["6", "9", "12", "18", "24"].map(m => <option key={m} value={m}>{m} Months</option>)}</select></div>
        <div style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", borderRadius: 12, padding: "16px", textAlign: "center" }}><div style={{ color: "rgba(7,21,16,0.6)", fontSize: 11, marginBottom: 3 }}>Monthly Payment</div><div style={{ fontWeight: 800, fontSize: 26, color: "#071510" }}>{monthly()}</div><div style={{ color: "rgba(7,21,16,0.5)", fontSize: 11, marginTop: 3 }}>Interest-free</div></div>
      </div>
      <button style={{ width: "100%", background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "14px", color: "#071510", fontWeight: 800, fontSize: 15, cursor: "pointer" }}>Apply for Rent Financing</button>
    </div>
  );
}

function Loans() {
  const [form, setForm] = useState(false);
  const [level, setLevel] = useState("");
  const cls: any = { nursery: ["Nursery 1", "Nursery 2", "Nursery 3"], primary: ["Primary 1", "Primary 2", "Primary 3", "Primary 4", "Primary 5", "Primary 6"], secondary: ["JSS 1", "JSS 2", "JSS 3", "SS 1", "SS 2", "SS 3"], university: ["Year 1", "Year 2", "Year 3", "Year 4", "Year 5"] };
  if (form) return (
    <div style={{ padding: 16 }}>
      <button onClick={() => setForm(false)} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.15)", borderRadius: 8, padding: "6px 12px", color: C.white, fontSize: 12, cursor: "pointer", marginBottom: 14 }}>← Back</button>
      <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 14 }}>School Fee Loan</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {[{ ph: "Student Name *" }, { ph: "School Name *" }, { ph: "Fee Amount (₦) *", type: "number" }].map(f => <input key={f.ph} type={f.type || "text"} placeholder={f.ph} style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 13, outline: "none" }} />)}
        <select value={level} onChange={e => setLevel(e.target.value)} style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "11px 13px", color: level ? C.white : C.muted, fontSize: 13, outline: "none" }}>
          <option value="">Education Level *</option>
          {Object.keys(cls).map(k => <option key={k} value={k}>{k.charAt(0).toUpperCase() + k.slice(1)}</option>)}
        </select>
        {level && <select style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 13, outline: "none" }}><option>Select Class *</option>{cls[level].map((c: string) => <option key={c}>{c}</option>)}</select>}
        <button onClick={() => alert("Submitted! Review in 24-48 hours.")} style={{ background: "linear-gradient(135deg,#a855f7,#0055ff)", border: "none", borderRadius: 12, padding: "14px", color: C.white, fontWeight: 800, fontSize: 15, cursor: "pointer" }}>Submit</button>
      </div>
    </div>
  );
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 14 }}>School Fee Loans</div>
      <div style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 14, padding: 14, marginBottom: 14 }}>
        {[{ l: "Rental History", v: "85%", p: 85 }, { l: "Payment History", v: "95%", p: 95 }, { l: "Transaction Volume", v: "78%", p: 78 }].map(s => (
          <div key={s.l} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}><span>{s.l}</span><span style={{ color: C.green, fontWeight: 600 }}>{s.v}</span></div>
            <div style={{ background: "rgba(255,255,255,0.06)", borderRadius: 99, height: 5 }}><div style={{ width: s.p + "%", height: "100%", background: "linear-gradient(90deg,#00e87a,#0055ff)", borderRadius: 99 }} /></div>
          </div>
        ))}
        <div style={{ background: "rgba(0,232,122,0.08)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 9, padding: "10px 12px", marginTop: 4 }}><div style={{ fontWeight: 700, color: C.green }}>Pre-Approved! 🎉</div><div style={{ color: C.muted, fontSize: 12 }}>Maximum: ₦500,000</div></div>
      </div>
      <button onClick={() => setForm(true)} style={{ width: "100%", background: "linear-gradient(135deg,#a855f7,#0055ff)", border: "none", borderRadius: 12, padding: "14px", color: C.white, fontWeight: 800, fontSize: 15, cursor: "pointer" }}>Apply for School Fee Loan</button>
    </div>
  );
}

function Chat() {
  const [chatWith, setChatWith] = useState<any>(null);
  const [chatType, setChatType] = useState("");
  const [msgs, setMsgs] = useState<any>({});
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, chatWith]);
  const send = () => {
    if (!input.trim() || !chatWith) return;
    const key = chatType + "-" + chatWith.id;
    setMsgs((p: any) => ({ ...p, [key]: [...(p[key] || []), { role: "me", text: input, t: new Date() }] }));
    setInput("");
    setTimeout(() => { const r = ["Okay 👍", "I'll check", "When?", "No problem"]; setMsgs((p: any) => ({ ...p, [chatType + "-" + chatWith.id]: [...(p[chatType + "-" + chatWith.id] || []), { role: "them", text: r[Math.floor(Math.random() * 4)], t: new Date() }] })); }, 2000);
  };
  const landlords = [{ id: 1, name: "Mr. Chukwu Obi", online: true }, { id: 2, name: "Mrs. Adaeze Nwosu", online: false }, { id: 3, name: "Chief Emeka Ike", online: true }];
  const fmt = (d: Date) => d?.toLocaleTimeString("en-NG", { hour: "2-digit", minute: "2-digit" });
  if (chatWith) return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 160px)" }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", alignItems: "center", gap: 12, background: "rgba(7,21,16,0.9)", flexShrink: 0 }}>
        <button onClick={() => setChatWith(null)} style={{ background: C.card, border: "none", borderRadius: 7, padding: "6px 10px", color: C.white, fontSize: 12, cursor: "pointer" }}>←</button>
        <div style={{ width: 34, height: 34, borderRadius: "50%", background: "rgba(0,232,122,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: C.green }}>{chatWith.name.slice(0, 2)}</div>
        <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{chatWith.name}</div><div style={{ color: chatWith.online ? C.green : C.muted, fontSize: 10 }}>{chatWith.online ? "Online" : "Offline"}</div></div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
        {!(msgs[chatType + "-" + chatWith.id] || []).length && <div style={{ textAlign: "center", padding: "40px 20px", color: C.muted }}><div style={{ fontSize: 40, marginBottom: 8 }}>💬</div><div>Start a conversation</div></div>}
        {(msgs[chatType + "-" + chatWith.id] || []).map((m: any, i: number) => (
          <div key={i} style={{ display: "flex", flexDirection: m.role === "me" ? "row-reverse" : "row", gap: 8, alignItems: "flex-end" }}>
            <div style={{ maxWidth: "75%" }}><div style={{ background: m.role === "me" ? "linear-gradient(135deg,#0055ff,#003ecc)" : "rgba(0,232,122,0.07)", borderRadius: m.role === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", padding: "10px 14px", color: C.white, fontSize: 13, lineHeight: 1.6 }}>{m.text}</div><div style={{ color: "rgba(255,255,255,0.2)", fontSize: 9, marginTop: 2, textAlign: m.role === "me" ? "right" : "left" }}>{fmt(m.t)}</div></div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div style={{ padding: "10px 14px 16px", background: "rgba(7,21,16,0.95)", borderTop: "1px solid rgba(0,232,122,0.1)", display: "flex", gap: 8, flexShrink: 0 }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", background: "rgba(0,232,122,0.04)", borderRadius: 24, padding: "10px 14px", border: "1px solid rgba(0,232,122,0.12)" }}><input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder={"Message " + chatWith.name + "..."} style={{ background: "none", border: "none", outline: "none", color: C.white, fontSize: 13, flex: 1 }} /></div>
        <button onClick={send} disabled={!input.trim()} style={{ width: 44, height: 44, borderRadius: "50%", background: input.trim() ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", cursor: input.trim() ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, color: input.trim() ? "#071510" : "rgba(255,255,255,0.2)" }}>➤</button>
      </div>
    </div>
  );
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 16 }}>Messages</div>
      <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 10 }}>Fellow Tenants</div>
      {TENANTS.filter(t => t.id !== 1).map(t => (
        <div key={t.id} onClick={() => { setChatWith(t); setChatType("tenant"); }} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 12, padding: "12px 14px", cursor: "pointer", display: "flex", gap: 12, alignItems: "center", marginBottom: 8 }}>
          <div style={{ position: "relative" }}><div style={{ width: 34, height: 34, borderRadius: "50%", background: "rgba(0,232,122,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: C.green }}>{t.name.slice(0, 2)}</div><span style={{ position: "absolute", bottom: 0, right: 0, width: 10, height: 10, borderRadius: "50%", background: t.online ? C.green : "rgba(255,255,255,0.2)", border: "2px solid #0a1a12" }} /></div>
          <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{t.name}</div><div style={{ color: C.muted, fontSize: 11 }}>{t.address}</div></div>
          <span style={{ background: "rgba(0,85,255,0.15)", color: "#60aaff", borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700 }}>Message</span>
        </div>
      ))}
      <div style={{ color: C.green, fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 10, marginTop: 16 }}>Landlords</div>
      {landlords.map(l => (
        <div key={l.id} onClick={() => { setChatWith(l); setChatType("landlord"); }} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 12, padding: "12px 14px", cursor: "pointer", display: "flex", gap: 12, alignItems: "center", marginBottom: 8 }}>
          <div style={{ position: "relative" }}><div style={{ width: 34, height: 34, borderRadius: "50%", background: "rgba(0,232,122,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: C.green }}>{l.name.slice(0, 2)}</div><span style={{ position: "absolute", bottom: 0, right: 0, width: 10, height: 10, borderRadius: "50%", background: l.online ? C.green : "rgba(255,255,255,0.2)", border: "2px solid #0a1a12" }} /></div>
          <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{l.name}</div></div>
          <span style={{ background: "rgba(0,232,122,0.1)", color: C.green, borderRadius: 20, padding: "2px 10px", fontSize: 10, fontWeight: 700 }}>🏢 Landlord</span>
        </div>
      ))}
    </div>
  );
}

function Pay() {
  const [step, setStep] = useState("amount");
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("");
  const [pin, setPin] = useState("");
  const [proc, setProc] = useState(false);
  const [done, setDone] = useState(false);
  const methods = [{ id: "card", label: "Debit Card", sub: "Visa / Mastercard / Verve" }, { id: "transfer", label: "Bank Transfer", sub: "Direct bank transfer" }, { id: "ussd", label: "USSD", sub: "*737# *901# *966#" }, { id: "wallet", label: "Wallet", sub: "Balance: ₦12,500" }];
  if (done) return <div style={{ padding: 24, display: "flex", flexDirection: "column", alignItems: "center", minHeight: "60vh", gap: 16, textAlign: "center", justifyContent: "center" }}><div style={{ fontSize: 80 }}>✅</div><div style={{ fontWeight: 800, fontSize: 22, color: C.green }}>Payment Successful!</div><div style={{ color: C.muted, fontSize: 14 }}>₦{parseInt(amount).toLocaleString()} sent to E-RentalHQ</div><button onClick={() => { setStep("amount"); setAmount(""); setMethod(""); setPin(""); setDone(false); }} style={{ width: "100%", background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "14px", color: "#071510", fontWeight: 800, fontSize: 15, cursor: "pointer" }}>Make Another Payment</button></div>;
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 4 }}>Make Payment</div>
      <div style={{ background: "rgba(255,68,68,0.07)", border: "1px solid rgba(255,68,68,0.2)", borderRadius: 14, padding: 16, marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div><div style={{ color: "#ff8888", fontSize: 12, fontWeight: 700, marginBottom: 2 }}>PAYMENT DUE</div><div style={{ fontWeight: 800, fontSize: 24, color: C.red }}>₦37,500</div><div style={{ color: C.muted, fontSize: 11 }}>Jan 2026 · 13 days</div></div>
        <div style={{ background: "rgba(255,68,68,0.12)", border: "2px solid " + C.red, borderRadius: 12, padding: "10px 14px", textAlign: "center" }}><div style={{ fontWeight: 800, fontSize: 26, color: C.red }}>13</div><div style={{ fontSize: 9, color: C.muted }}>days</div></div>
      </div>
      {step === "amount" && <><input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Enter amount" style={{ width: "100%", background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 10, padding: "14px", color: C.white, fontSize: 20, outline: "none", marginBottom: 8 }} /><div style={{ display: "flex", gap: 8, marginBottom: 14 }}>{["37500", "18750", "75000"].map(a => <button key={a} onClick={() => setAmount(a)} style={{ flex: 1, background: amount === a ? "rgba(0,232,122,0.12)" : C.card, border: "1px solid " + (amount === a ? "rgba(0,232,122,0.3)" : C.border), borderRadius: 8, padding: "7px", color: amount === a ? C.green : C.muted, fontSize: 11, fontWeight: 600, cursor: "pointer" }}>₦{parseInt(a).toLocaleString()}</button>)}</div><button onClick={() => amount && setStep("method")} disabled={!amount} style={{ width: "100%", background: amount ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 12, padding: "14px", color: amount ? "#071510" : C.muted, fontWeight: 800, fontSize: 15, cursor: amount ? "pointer" : "not-allowed" }}>Continue →</button></>}
      {step === "method" && <>{methods.map(m => <div key={m.id} onClick={() => setMethod(m.id)} style={{ background: method === m.id ? "rgba(0,232,122,0.08)" : C.card, border: "1px solid " + (method === m.id ? "rgba(0,232,122,0.3)" : C.border), borderRadius: 12, padding: "14px 16px", cursor: "pointer", display: "flex", alignItems: "center", gap: 14, marginBottom: 10 }}><div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{m.label}</div><div style={{ color: C.muted, fontSize: 11, marginTop: 2 }}>{m.sub}</div></div><div style={{ width: 20, height: 20, borderRadius: "50%", border: "2px solid " + (method === m.id ? C.green : C.border), display: "flex", alignItems: "center", justifyContent: "center" }}>{method === m.id && <div style={{ width: 10, height: 10, borderRadius: "50%", background: C.green }} />}</div></div>)}<div style={{ display: "flex", gap: 10 }}><button onClick={() => setStep("amount")} style={{ flex: 1, background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: "13px", color: C.muted, fontWeight: 700, cursor: "pointer" }}>←</button><button onClick={() => method && setStep("pin")} disabled={!method} style={{ flex: 2, background: method ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 12, padding: "13px", color: method ? "#071510" : C.muted, fontWeight: 800, cursor: method ? "pointer" : "not-allowed" }}>Pay ₦{parseInt(amount || "0").toLocaleString()}</button></div></>}
      {step === "pin" && <><div style={{ textAlign: "center", padding: "20px 0" }}><div style={{ fontSize: 50, marginBottom: 12 }}>🔐</div><div style={{ fontWeight: 800, fontSize: 18, marginBottom: 20 }}>Enter PIN</div><div style={{ display: "flex", justifyContent: "center", gap: 12, marginBottom: 24 }}>{[0, 1, 2, 3].map(i => <div key={i} style={{ width: 16, height: 16, borderRadius: "50%", background: pin.length > i ? C.green : "rgba(255,255,255,0.1)", border: "2px solid " + (pin.length > i ? C.green : C.border) }} />)}</div><div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, maxWidth: 260, margin: "0 auto" }}>{[1, 2, 3, 4, 5, 6, 7, 8, 9, "*", 0, "⌫"].map((k, idx) => <button key={idx} onClick={() => { if (k === "⌫") setPin(p => p.slice(0, -1)); else if (k !== "*" && pin.length < 4) setPin(p => p + k); }} style={{ height: 56, borderRadius: 12, background: k === "*" ? C.card : "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.1)", color: C.white, fontSize: k === "⌫" ? 20 : 22, fontWeight: 700, cursor: k === "*" ? "default" : "pointer" }}>{k}</button>)}</div></div>{proc ? <div style={{ textAlign: "center", padding: "20px 0" }}><div style={{ width: 40, height: 40, borderRadius: "50%", border: "3px solid " + C.green, borderTop: "3px solid transparent", animation: "spin 1s linear infinite", margin: "0 auto 12px" }} /><div style={{ color: C.green, fontWeight: 700 }}>Processing...</div></div> : <div style={{ display: "flex", gap: 10, marginTop: 16 }}><button onClick={() => setStep("method")} style={{ flex: 1, background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: "13px", color: C.muted, fontWeight: 700, cursor: "pointer" }}>←</button><button onClick={() => { setProc(true); setTimeout(() => { setProc(false); setDone(true); }, 3000); }} disabled={pin.length < 4} style={{ flex: 2, background: pin.length === 4 ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 12, padding: "13px", color: pin.length === 4 ? "#071510" : C.muted, fontWeight: 800, cursor: pin.length === 4 ? "pointer" : "not-allowed" }}>Confirm</button></div>}</>}
    </div>
  );
}

function MyLink() {
  const [copied, setCopied] = useState(false);
  const link = "https://erentalhq.com/ref/chidi-ERH2024";
  const copy = () => { navigator.clipboard?.writeText(link).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 2500); };
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 4 }}>My Referral Link</div>
      <div style={{ color: C.muted, fontSize: 13, marginBottom: 16 }}>Share E-RentalHQ. Earn ₦1,000 per signup.</div>
      <div style={{ background: "linear-gradient(135deg,rgba(0,232,122,0.1),rgba(0,85,255,0.08))", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 16, padding: 18, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, fontSize: 14, color: C.green, marginBottom: 4 }}>erh.ng/c/ERH2024</div>
        <div style={{ color: "rgba(255,255,255,0.3)", fontSize: 11, marginBottom: 14, wordBreak: "break-all" }}>{link}</div>
        <button onClick={copy} style={{ width: "100%", background: copied ? "rgba(0,232,122,0.15)" : "linear-gradient(135deg,#00e87a,#009e54)", border: copied ? "1px solid rgba(0,232,122,0.4)" : "none", borderRadius: 10, padding: "12px", color: copied ? C.green : "#071510", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>{copied ? "✓ Copied!" : "📋 Copy My Link"}</button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>{[{ l: "Clicks", v: "47" }, { l: "Opens", v: "23" }, { l: "Signups", v: "3" }, { l: "Earned", v: "₦3,000" }].map(s => <div key={s.l} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.1)", borderRadius: 12, padding: "12px 14px" }}><div style={{ fontWeight: 800, fontSize: 20, color: s.l === "Earned" ? C.green : C.white }}>{s.v}</div><div style={{ color: C.muted, fontSize: 11 }}>{s.l}</div></div>)}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10 }}>{[{ label: "WhatsApp", color: "#25d366", action: () => window.open("https://wa.me/?text=Check+E-RentalHQ+" + link) }, { label: "SMS", color: C.orange, action: () => window.open("sms:?body=Check+E-RentalHQ+" + link) }, { label: "Copy", color: C.green, action: copy }].map(s => <button key={s.label} onClick={s.action} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 12, padding: "14px 8px", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}><span style={{ color: s.color, fontSize: 11, fontWeight: 700 }}>{s.label}</span></button>)}</div>
    </div>
  );
}

function LDash() {
  const [emerg, setEmerg] = useState<any>(null);
  const [amount, setAmount] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [chatT, setChatT] = useState<any>(null);
  const [msgs, setMsgs] = useState<any>({});
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, chatT]);
  const send = () => {
    if (!input.trim() || !chatT) return;
    const key = "l-" + chatT.id;
    setMsgs((p: any) => ({ ...p, [key]: [...(p[key] || []), { role: "me", text: input, t: new Date() }] }));
    setInput("");
    setTimeout(() => { const r = ["Okay", "I'll check", "Thanks", "Give me time"]; setMsgs((p: any) => ({ ...p, ["l-" + chatT.id]: [...(p["l-" + chatT.id] || []), { role: "them", text: r[Math.floor(Math.random() * 4)], t: new Date() }] })); }, 2000);
  };
  if (chatT) return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 120px)" }}>
      <div style={{ padding: "10px 16px", borderBottom: "1px solid rgba(0,232,122,0.1)", display: "flex", alignItems: "center", gap: 12, background: "rgba(7,21,16,0.9)", flexShrink: 0 }}>
        <button onClick={() => setChatT(null)} style={{ background: C.card, border: "none", borderRadius: 7, padding: "6px 10px", color: C.white, fontSize: 12, cursor: "pointer" }}>←</button>
        <div style={{ width: 34, height: 34, borderRadius: "50%", background: "rgba(0,232,122,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: C.green }}>{chatT.name.slice(0, 2)}</div>
        <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{chatT.name}</div></div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
        {!(msgs["l-" + chatT.id] || []).length && <div style={{ textAlign: "center", padding: "40px 20px", color: C.muted }}><div style={{ fontSize: 40, marginBottom: 8 }}>💬</div><div>Message {chatT.name}</div></div>}
        {(msgs["l-" + chatT.id] || []).map((m: any, i: number) => <div key={i} style={{ display: "flex", flexDirection: m.role === "me" ? "row-reverse" : "row", gap: 8 }}><div style={{ maxWidth: "75%" }}><div style={{ background: m.role === "me" ? "linear-gradient(135deg,#0055ff,#003ecc)" : "rgba(0,232,122,0.07)", borderRadius: m.role === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", padding: "10px 14px", color: C.white, fontSize: 13 }}>{m.text}</div></div></div>)}
        <div ref={endRef} />
      </div>
      <div style={{ padding: "10px 14px 16px", background: "rgba(7,21,16,0.95)", borderTop: "1px solid rgba(0,232,122,0.1)", display: "flex", gap: 8, flexShrink: 0 }}>
        <div style={{ flex: 1, display: "flex", alignItems: "center", background: "rgba(0,232,122,0.04)", borderRadius: 24, padding: "10px 14px", border: "1px solid rgba(0,232,122,0.12)" }}><input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder={"Message " + chatT.name + "..."} style={{ background: "none", border: "none", outline: "none", color: C.white, fontSize: 13, flex: 1 }} /></div>
        <button onClick={send} disabled={!input.trim()} style={{ width: 44, height: 44, borderRadius: "50%", background: input.trim() ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", cursor: input.trim() ? "pointer" : "not-allowed", fontSize: 16, color: input.trim() ? "#071510" : "rgba(255,255,255,0.2)" }}>➤</button>
      </div>
    </div>
  );
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 14 }}>Dashboard</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>{[{ l: "Tenants", v: 4, c: "#60aaff" }, { l: "Properties", v: 3, c: C.green }, { l: "Income/mo", v: "₦150k", c: C.purple }, { l: "Next Due", v: "13d", c: C.orange }].map(s => <div key={s.l} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 12, padding: 14 }}><div style={{ color: C.muted, fontSize: 11, marginBottom: 3 }}>{s.l}</div><div style={{ fontWeight: 800, fontSize: 22, color: s.c }}>{s.v}</div></div>)}</div>
      <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10, color: C.green }}>Tenants</div>
      {TENANTS.map(t => (
        <div key={t.id} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 14, padding: 14, marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 12, marginBottom: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: "rgba(0,232,122,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 800, color: C.green }}>{t.name.slice(0, 2)}</div>
            <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 14 }}>{t.name}</div><div style={{ color: C.muted, fontSize: 11 }}>{t.age}y · {t.gender} · {t.address}</div></div>
            <div style={{ background: t.days <= 14 ? "rgba(255,68,68,0.12)" : t.days <= 30 ? "rgba(255,149,0,0.1)" : "rgba(0,232,122,0.08)", border: "2px solid " + (t.days <= 14 ? C.red : t.days <= 30 ? C.orange : C.green), borderRadius: 10, padding: "7px 10px", textAlign: "center", flexShrink: 0 }}><div style={{ fontWeight: 800, fontSize: 20, color: t.days <= 14 ? C.red : t.days <= 30 ? C.orange : C.green }}>{t.days}</div><div style={{ fontSize: 8, color: C.muted }}>days</div></div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setChatT(t)} style={{ flex: 1, background: "rgba(0,85,255,0.1)", border: "1px solid rgba(0,85,255,0.25)", borderRadius: 9, padding: "9px", color: "#60aaff", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>💬 Message</button>
            <button onClick={() => { setEmerg(t); setAmount(""); setVerifying(false); setVerified(false); }} style={{ flex: 1, background: "rgba(255,149,0,0.08)", border: "1px solid rgba(255,149,0,0.25)", borderRadius: 9, padding: "9px", color: C.orange, fontWeight: 700, fontSize: 12, cursor: "pointer" }}>🚨 Emergency</button>
          </div>
        </div>
      ))}
      {emerg && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, padding: 20 }}>
          <div style={{ background: "linear-gradient(135deg,#0a1a12,#0d1b2a)", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 18, padding: 22, width: "100%", maxWidth: 360 }}>
            {!verified ? <><div style={{ fontWeight: 800, fontSize: 16, marginBottom: 4 }}>Emergency Fund for {emerg.name}</div><input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount (₦)" style={{ width: "100%", background: "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 9, padding: "11px 13px", color: C.white, fontSize: 15, outline: "none", marginBottom: 12 }} />{verifying ? <div style={{ textAlign: "center", padding: "20px 0" }}><div style={{ width: 40, height: 40, borderRadius: "50%", border: "3px solid " + C.orange, borderTop: "3px solid transparent", animation: "spin 1s linear infinite", margin: "0 auto 12px" }} /><div style={{ color: C.orange, fontWeight: 700 }}>Verifying Face ID...</div></div> : <div style={{ display: "flex", gap: 10 }}><button onClick={() => setEmerg(null)} style={{ flex: 1, background: C.card, border: "none", borderRadius: 9, padding: "11px", color: C.muted, fontWeight: 700, cursor: "pointer", fontSize: 13 }}>Cancel</button><button onClick={() => { setVerifying(true); setTimeout(() => { setVerifying(false); setVerified(true); }, 2000); }} disabled={!amount} style={{ flex: 1, background: amount ? C.orange : C.card, border: "none", borderRadius: 9, padding: "11px", color: amount ? "#000" : C.muted, fontWeight: 700, cursor: amount ? "pointer" : "not-allowed", fontSize: 13 }}>Face ID</button></div>}</> : <div style={{ textAlign: "center", padding: "10px 0" }}><div style={{ fontSize: 50, marginBottom: 10 }}>✅</div><div style={{ fontWeight: 800, fontSize: 16, marginBottom: 6 }}>Sent!</div><div style={{ color: C.muted, fontSize: 13, marginBottom: 16 }}>₦{parseInt(amount).toLocaleString()} to {emerg.name}</div><button onClick={() => setEmerg(null)} style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 9, padding: "11px 24px", color: "#071510", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>Done</button></div>}
          </div>
        </div>
      )}
    </div>
  );
}

function ListProp() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ address: "", rent: "", bedrooms: "" });
  const [photos, setPhotos] = useState<any[]>([]);
  const [submitted, setSubmitted] = useState(false);
  if (submitted) return <div style={{ padding: 24, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "60vh", gap: 16, textAlign: "center" }}><div style={{ fontSize: 80 }}>🎉</div><div style={{ fontWeight: 800, fontSize: 22, color: C.green }}>Property Listed!</div><div style={{ background: "rgba(0,232,122,0.06)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 14, padding: 16, width: "100%" }}>{[{ l: "Address", v: form.address }, { l: "Rent", v: "₦" + parseInt(form.rent || "0").toLocaleString() }, { l: "Bedrooms", v: form.bedrooms + "-bed" }, { l: "Photos", v: photos.length + " added" }, { l: "Status", v: "Under Review" }].map(s => <div key={s.l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(0,232,122,0.06)" }}><span style={{ color: C.muted, fontSize: 12 }}>{s.l}</span><span style={{ fontWeight: 700, fontSize: 12, color: s.l === "Status" ? C.orange : C.white }}>{s.v}</span></div>)}</div><button onClick={() => { setSubmitted(false); setStep(1); setPhotos([]); setForm({ address: "", rent: "", bedrooms: "" }); }} style={{ width: "100%", background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "14px", color: "#071510", fontWeight: 800, fontSize: 15, cursor: "pointer" }}>List Another</button></div>;
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 4 }}>List Your Property</div>
      <div style={{ color: C.muted, fontSize: 13, marginBottom: 16 }}>Get paid 60 days early. Zero agent fees.</div>
      <div style={{ display: "flex", gap: 4, marginBottom: 20 }}>{[1, 2, 3].map(s => <div key={s} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}><div style={{ width: "100%", height: 4, borderRadius: 2, background: step >= s ? "linear-gradient(90deg,#00e87a,#009e54)" : "rgba(255,255,255,0.1)" }} /><span style={{ fontSize: 9, color: step >= s ? C.green : C.muted, fontWeight: 700 }}>{["Details", "Photos", "Confirm"][s - 1]}</span></div>)}</div>
      {step === 1 && <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="Property Address *" style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "12px 13px", color: C.white, fontSize: 13, outline: "none" }} />
        <input value={form.rent} onChange={e => setForm(f => ({ ...f, rent: e.target.value }))} placeholder="Annual Rent (₦) *" type="number" style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "12px 13px", color: C.white, fontSize: 13, outline: "none" }} />
        <select value={form.bedrooms} onChange={e => setForm(f => ({ ...f, bedrooms: e.target.value }))} style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "12px 13px", color: form.bedrooms ? C.white : C.muted, fontSize: 13, outline: "none" }}>
          <option value="">Select Bedrooms *</option>
          {["1", "2", "3", "4", "5+"].map(n => <option key={n} value={n}>{n} Bedroom{n !== "1" ? "s" : ""}</option>)}
        </select>
        <textarea placeholder="Property Description" rows={3} style={{ background: "rgba(0,232,122,0.04)", border: "1px solid rgba(0,232,122,0.12)", borderRadius: 9, padding: "12px 13px", color: C.white, fontSize: 13, outline: "none", resize: "none" }} />
        <button onClick={() => form.address && form.rent && form.bedrooms && setStep(2)} style={{ width: "100%", background: form.address && form.rent && form.bedrooms ? "linear-gradient(135deg,#00e87a,#009e54)" : C.card, border: "none", borderRadius: 12, padding: "14px", color: form.address && form.rent && form.bedrooms ? "#071510" : C.muted, fontWeight: 800, fontSize: 15, cursor: form.address && form.rent && form.bedrooms ? "pointer" : "not-allowed" }}>Next: Add Photos →</button>
      </div>}
      {step === 2 && <div>
        <div style={{ background: "rgba(0,232,122,0.05)", border: "1px dashed rgba(0,232,122,0.3)", borderRadius: 14, padding: 24, textAlign: "center", marginBottom: 14 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>📸</div>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>Add Property Photos</div>
          <div style={{ color: C.muted, fontSize: 12, marginBottom: 14 }}>GPS auto-tagged · Up to 8 photos</div>
          <button onClick={() => { if (photos.length < 8) setPhotos(p => [...p, { id: p.length + 1, label: "Photo " + (p.length + 1) }]); }} style={{ background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 9, padding: "9px 18px", color: "#071510", fontWeight: 700, cursor: "pointer", fontSize: 13 }}>📷 Add Photo</button>
        </div>
        {photos.length > 0 && <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8, marginBottom: 14 }}>{photos.map(ph => <div key={ph.id} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 10, padding: "12px 8px", textAlign: "center", position: "relative" }}><div style={{ color: C.green, fontWeight: 700, marginBottom: 4 }}>✅</div><div style={{ fontSize: 9, color: C.green, fontWeight: 600 }}>{ph.label}</div><button onClick={() => setPhotos(p => p.filter((x: any) => x.id !== ph.id))} style={{ position: "absolute", top: 4, right: 4, background: "rgba(255,68,68,0.2)", border: "none", borderRadius: "50%", width: 16, height: 16, color: C.red, fontSize: 9, cursor: "pointer" }}>✕</button></div>)}</div>}
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => setStep(1)} style={{ flex: 1, background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: "13px", color: C.muted, fontWeight: 700, cursor: "pointer" }}>← Back</button>
          <button onClick={() => setStep(3)} style={{ flex: 2, background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "13px", color: "#071510", fontWeight: 800, cursor: "pointer" }}>Next: Confirm →</button>
        </div>
      </div>}
      {step === 3 && <div>
        <div style={{ background: "rgba(0,232,122,0.06)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 14, padding: 16, marginBottom: 14 }}>{[{ l: "Address", v: form.address }, { l: "Annual Rent", v: "₦" + parseInt(form.rent || "0").toLocaleString() }, { l: "Bedrooms", v: form.bedrooms + "-bed" }, { l: "Photos", v: photos.length + " added" }].map(s => <div key={s.l} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(0,232,122,0.06)" }}><span style={{ color: C.muted, fontSize: 13 }}>{s.l}</span><span style={{ fontWeight: 700, fontSize: 13 }}>{s.v}</span></div>)}</div>
        <div style={{ background: "rgba(0,232,122,0.05)", border: "1px solid rgba(0,232,122,0.15)", borderRadius: 12, padding: 14, marginBottom: 14, fontSize: 13, lineHeight: 1.6, color: "rgba(255,255,255,0.8)" }}>✅ E-RentalHQ will pay you the full annual rent 60 days before expiry. Tenants repay us monthly.</div>
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => setStep(2)} style={{ flex: 1, background: C.card, border: "1px solid rgba(0,232,122,0.12)", borderRadius: 12, padding: "13px", color: C.muted, fontWeight: 700, cursor: "pointer" }}>← Back</button>
          <button onClick={() => setSubmitted(true)} style={{ flex: 2, background: "linear-gradient(135deg,#00e87a,#009e54)", border: "none", borderRadius: 12, padding: "13px", color: "#071510", fontWeight: 800, cursor: "pointer" }}>Submit Listing 🎉</button>
        </div>
      </div>}
    </div>
  );
}

function Earn() {
  return (
    <div style={{ padding: 16 }}>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 4 }}>Earnings</div>
      <div style={{ background: "linear-gradient(135deg,rgba(0,232,122,0.12),rgba(0,85,255,0.08))", border: "1px solid rgba(0,232,122,0.2)", borderRadius: 16, padding: 18, marginBottom: 16, textAlign: "center" }}>
        <div style={{ color: C.muted, fontSize: 12, marginBottom: 4 }}>Total This Year</div>
        <div style={{ fontWeight: 800, fontSize: 32, color: C.green }}>₦1,800,000</div>
        <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>Paid 60 days early by E-RentalHQ</div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>{[{ l: "This Month", v: "₦150,000", c: C.green }, { l: "Tenants", v: "4 Active", c: "#60aaff" }, { l: "Next Due", v: "13 days", c: C.orange }, { l: "Properties", v: "3", c: C.purple }].map(s => <div key={s.l} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 12, padding: 14 }}><div style={{ color: C.muted, fontSize: 11, marginBottom: 3 }}>{s.l}</div><div style={{ fontWeight: 800, fontSize: 18, color: s.c }}>{s.v}</div></div>)}</div>
      <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10, color: C.green }}>Payment History</div>
      {[{ d: "Jan 2026", t: "Chidi Okafor", a: "₦450,000" }, { d: "Oct 2025", t: "Ngozi Adeyemi", a: "₦380,000" }, { d: "Jul 2025", t: "Emeka Nwankwo", a: "₦550,000" }, { d: "Mar 2025", t: "Fatima Ibrahim", a: "₦420,000" }].map((p, i) => <div key={i} style={{ background: C.card, border: "1px solid rgba(0,232,122,0.08)", borderRadius: 12, padding: "12px 14px", marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}><div><div style={{ fontWeight: 600, fontSize: 13 }}>{p.t}</div><div style={{ color: C.muted, fontSize: 11 }}>{p.d}</div></div><div style={{ textAlign: "right" }}><div style={{ fontWeight: 800, fontSize: 14, color: C.green }}>{p.a}</div><span style={{ background: "rgba(0,232,122,0.12)", color: C.green, borderRadius: 20, padding: "2px 8px", fontSize: 10, fontWeight: 700 }}>Received</span></div></div>)}
    </div>
  );
}


